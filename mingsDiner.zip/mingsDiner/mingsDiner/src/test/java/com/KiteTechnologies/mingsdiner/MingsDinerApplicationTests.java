package com.KiteTechnologies.mingsdiner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MingsDinerApplicationTests {

	@Test
	void contextLoads() {
	}

}
